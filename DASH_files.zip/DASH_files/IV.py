#IV 
import json
import pandas as pd
import matplotlib.pyplot as plt
class JsonData:

    def __init__(self, json_FP):
        with open(json_FP) as file:
            data = json.load(file)
            self.results = data.get('results', {}) #starts search when sees this keyword and braces
    

    def get_current(self):
        return self.results.get('CURRENT', [])    
    
    def get_voltage(self):
        return self.results.get('VOLTAGE', [])


json_data = JsonData("N:\\CERN\\W3_Run_63\\results\\SN20USBHX2001092_UNKNOWN_20231009_63_18_MODULE_IV_AMAC.json")
currents = json_data.get_current()     #applies function to json_data & give them to 2 arrays of current & voltage
voltages = json_data.get_voltage()

#iv_df = pd.DataFrame(list(zip(voltages, currents)), 
#                     columns=['Bias Voltage', 'Current'])

#print(iv_df)

plt.plot(voltages, currents)
plt.title("IV SCAN", fontsize = 22, fontname = "FreeSerif" )
plt.xlabel("Bias Voltage [V]")
plt.ylabel("Current [μA]")
#plt.show()


"N:\CERN\W3_Run_63\data\strun63_3.root"


#N:\CERN

#path = "N:\\CERN\\W3_Run_63\\results\\SN20USBHX2001092_UNKNOWN_20231009_63_18_MODULE_IV_AMAC.json"
