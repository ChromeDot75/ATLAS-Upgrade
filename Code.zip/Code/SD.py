import uproot 
import matplotlib.pyplot as plt
import plotly.express as px
import pandas as pd


fh = uproot.open(r"N:\CERN\W3_Run_63\data\strun63_3.root")

h_scan = fh["h_scan0"]

data_transposed = h_scan.values().T


fig, ax = plt.subplots() 

df = pd.DataFrame(data_transposed)

SD = ax.imshow(df, aspect = 'auto')

"""
fig_px = px.density_heatmap(df)
fig_px.show()
#print(df)
"""
colorbar = plt.colorbar(SD, pad=0.02)
plt.xlabel("Channel number")  
plt.ylabel("Counts")  
plt.title("Strobe Delay")
plt.show()  

"""
#print(h_scan.values(2))

import uproot
import matplotlib.pyplot as plt

# Open the ROOT file
fh = uproot.open(r"N:\CERN\W3_Run_63\data\strun63_3.root")

# Access the histogram

h_scan = fh["h_scan0"]

# Plot the histogram with swapped x and y axes
fig, ax = plt.subplots()
ax.imshow(h_scan.values(), aspect='auto', extent=(h_scan.edges[1][0], h_scan.edges[1][-1], h_scan.edges[0][-1], h_scan.edges[0][0]))
plt.xlabel("Y-axis label")  # Replace with your actual Y-axis label
plt.ylabel("X-axis label")  # Replace with your actual X-axis label
plt.title("Flipped Axes: h_scan0")
plt.show()

fig, ax = plt.subplots()

ax, imshow
print(fh.keys(recursive=False))
print(fh.typenames(recursive=False))

print(fh.values(recursive=False))
"""