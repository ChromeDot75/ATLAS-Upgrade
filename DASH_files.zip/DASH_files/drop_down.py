from dash import Dash, html, dcc
from dash import callback, Input, Output
from dash.dependencies import Input, Output
from typing import List
import ids 

def render(app: Dash) -> html.Div: 
    all_runs = ["Run 63", "Run 697"]
    
    @app.callback(
        Output(ids.RUN_DROPDOWN, "value"),
        Input(ids.SELECT_ALL_RUNS_BUTTON, "n_clicks" )
    )
    def select_all_runs(n_clicks: int) -> List[str]:
        return all_runs
    return html.Div(
        children=[
            html.H6("Runs"),
            dcc.Dropdown(
                id = ids.RUN_DROPDOWN,
                options = [{"label" : Run, "value": Run} for Run in all_runs],
                value= all_runs,
                multi=True,
            ),
            html.Button(
                className="dropdown-button",
                children="[Select All]",
                id = ids.SELECT_ALL_RUNS_BUTTON,
            )
            
        ]
    )