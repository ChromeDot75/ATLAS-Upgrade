from dash import Dash, html, dcc, callback, Output, Input
import dash
from IV import currents, voltages
import pandas as pd
from SD import SD
from PTS import PTS
import matplotlib.pyplot as plt
import plotly.express as px

#Creating Dataframe: 

app = dash.Dash(__name__)

# Define layout
app.layout = html.Div(children=[
    html.H1("Current vs. Voltage Plot"),
    
    # Scatter plot
    dcc.Graph(
        id='current-voltage-plot',
        figure=px.scatter(x=voltages, y=currents, labels={'x': 'Current', 'y': 'Voltage'},
                          title='Current vs. Voltage Plot')
    )
])

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
    
    
    """
    plt.plot(iv_df)
    plt.title("IV SCAN", fontsize = 22, fontname = "FreeSerif" )
    plt.xlabel("Bias Voltage/V")
    plt.ylabel("Current/nA")
    """