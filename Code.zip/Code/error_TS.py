#Fitting Error Function on TS
import uproot 
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import numpy as np
from scipy.stats import norm
from scipy.special import erfc

fh = uproot.open(r"N:\CERN\W3_Run_63\data\strun63_4.root")
hist = fh['h_scan0;1']
values = hist.values()[1]
x_values = np.linspace(0, 80, len(values))

# Define the complementary error function (erfc) as the fitting function
def erfc_fit(x, A, mu, sigma, offset):
    return A * erfc((x - mu) / (sigma * np.sqrt(2))) + offset

# Initial guess for the parameters
initial_guess = [1.0, np.mean(x_values), np.std(x_values), 0.0]

# Fit the data to the erfc function
params, covariance = curve_fit(erfc_fit, x_values, values, p0=initial_guess)

# Generate y values using the fitted parameters
y_fit = erfc_fit(x_values, *params)

equation = f"y = {params[0]:.4f} * erfc((x - {params[1]:.4f}) / ({params[2]:.4f} * sqrt(2))) + {params[3]:.4f}"
print("Fitted Equation:", equation)

x_point = 21.96
y_point = 511.45
plt.scatter(x_point, y_point, color='green', marker='o', label='mean')

# Plot the original data points
plt.plot(x_values, values, label='Data Points')

# Plot the fitted erfc function
plt.plot(x_values, y_fit, label='Fitted erfc', linestyle='--')

# Customize the plot
plt.title('Threshold scan fitted with a complementary error function')
plt.xlabel('Threshold [mV]')
plt.ylabel('n [Events]')
plt.legend()

# Show the plot
#plt.show()