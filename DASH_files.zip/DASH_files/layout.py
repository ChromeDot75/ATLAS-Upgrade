from dash import Dash, html
import drop_down



def create_layout(app: Dash) -> html.Div:
    return html.Div(className="app-div", children=[html.H1(app.title), html.Hr(),
    html.Div(
        className="dropdown-container",
        children=[
            drop_down.render(app)
        ]
    
    )])
   